rem  protection mode, the protection level, the role of the database, and switchover status:
SELECT DATABASE_ROLE, DB_UNIQUE_NAME INSTANCE, OPEN_MODE, PROTECTION_MODE, PROTECTION_LEVEL, SWITCHOVER_STATUS 
FROM V$DATABASE;

rem On the standby database, query the V$ARCHIVED_LOG view to identify existing files in the archived redo log.
column ts_first_change format a19
column ts_next_change format a19
column blocks format 999,999,999

SELECT SEQUENCE#
      ,to_char(FIRST_TIME,'DD/MM/YY HH24:MI:SS') ts_first_change
      ,to_char(NEXT_TIME,'DD/MM/YY HH24:MI:SS') ts_next_change
      ,blocks
      ,creator
      ,applied
FROM V$ARCHIVED_LOG 
ORDER BY SEQUENCE#;

SELECT THREAD#, MAX(SEQUENCE#) AS "LAST_APPLIED_LOG" 
FROM V$LOG_HISTORY 
GROUP BY THREAD#;

rem On the standby database, query the V$ARCHIVED_LOG view to verify the archived redo log files were applied.
SELECT SEQUENCE#,APPLIED 
FROM V$ARCHIVED_LOG 
ORDER BY SEQUENCE#;

rem query the physical standby database to monitor Redo Apply and redo transport services activity at the standby site.
SELECT PROCESS, STATUS, THREAD#, SEQUENCE#, BLOCK#, BLOCKS 
FROM V$MANAGED_STANDBY;

rem To determine if real-time apply is enabled, query the RECOVERY_MODE column of the V$ARCHIVE_DEST_STATUS view.
SELECT type,RECOVERY_MODE , database_mode
FROM V$ARCHIVE_DEST_STATUS
where database_mode not like 'UNKNOWN';

rem The V$DATAGUARD_STATUS fixed view displays events that would typically be triggered by any message to the alert log or server process trace files.
set lines 200
set pages 50
column message format a100 wrap
SELECT message_num, severity, MESSAGE 
FROM V$DATAGUARD_STATUS
order by message_num desc
fetch first 50 rows only;

rem Determining Which Log Files Were Not Received by the Standby Site.
SELECT LOCAL.THREAD#, LOCAL.SEQUENCE# 
  FROM (SELECT THREAD#, SEQUENCE# 
          FROM V$ARCHIVED_LOG 
         WHERE DEST_ID=1) LOCAL 
 WHERE LOCAL.SEQUENCE# NOT IN (SELECT SEQUENCE# 
                                 FROM V$ARCHIVED_LOG 
                                WHERE DEST_ID=2 AND THREAD# = LOCAL.THREAD#);
                               
rem If a delayed apply has been specified or an archive log is missing then switchover may take longer than expected.
rem Check v$managed_standby
select process, status, sequence# 
from v$managed_standby;
rem OR alternatively:
column name format a80 trunc
select name, applied 
from v$archived_log;
--------------------------------------------------------------

