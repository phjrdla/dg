startup nomount pfile='/tmp/LABDG2_init_4_dup.ora';
