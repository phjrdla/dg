set linesize 80
column  HOST_NAME format a30 trunc
select INSTANCE_NAME ,  HOST_NAME from v$instance
/
