set lines 200
set pages 50
select * from v$standby_log
/
