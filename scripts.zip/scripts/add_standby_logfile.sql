alter database add standby logfile thread 1 size 200m;
alter database add standby logfile thread 1 size 200m;
alter database add standby logfile thread 1 size 200m;
alter database add standby logfile thread 1 size 200m;
