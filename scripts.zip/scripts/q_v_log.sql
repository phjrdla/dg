set lines 200

select *
  from v$log;
