Alter system set db_block_checksum = typical scope=both;
Alter system set db_block_checking = full scope=both;


