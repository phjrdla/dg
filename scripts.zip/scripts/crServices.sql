-- Creation
begin
  dbms_service.delete_service(service_name => 'COSWARE' );
  dbms_service.delete_service(service_name => 'COSWARERO' );
  dbms_service.create_service( service_name     => 'COSWARE'
                              ,network_name     => 'COSWARE'
 );

  dbms_service.create_service( service_name     => 'COSWARERO'
                              ,network_name     => 'COSWARERO'
 );
end;
/
-- Activation 
Begin
   dbms_service.start_service('COSWARE');
   dbms_service.start_service('COSWARERO');
end;
/
-- Trigger managing the services
create or replace trigger set_services_prm_stby after db_role_change on database
declare
  db_role varchar2(16);
  db_mode varchar2(20);
begin
--
-- primary database           COSWARE
-- standby database read only COSWARERO
--
  select database_role, open_mode into db_role, db_mode from v$database;
  if db_role = 'PRIMARY' then
    dbms_service.start_service('COSWARE');
    dbms_service.stop_service('COSWARERO');
  elsif (db_role = 'PHYSICAL STANDBY') and (db_mode = 'READ ONLY') then
    dbms_service.start_service('COSWARERO');
    dbms_service.stop_service('COSWARE');
  else
    dbms_service.stop_service('COSWARE');
    dbms_service.stop_service('COSWARERO');
  end if;
end;
/


