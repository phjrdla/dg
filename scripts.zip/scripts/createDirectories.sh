mkdir -p /u01/app/oracle/product/12.2.0.1/db_1
chown -R oracle:oinstall /u01
chmod -R 775 /u01

mkdir -p /u02/oradata
chown -R oracle:oinstall /u02
chmod -R 775 /u02

mkdir -p /u03/oradata
chown -R oracle:oinstall /u03
chmod -R 775 /u03

mkdir -p /u04/oradata
chown -R oracle:oinstall /u04
chmod -R 775 /u04

