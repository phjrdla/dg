#!/bin/ksh

cat <<!
This is $0
Returns database role (primary/standby)
!

typeset -u srvname
while [[ -z "$srvname" ]]
do
  read srvname?"Enter database or service name (q to quit) :"
  [[ $srvname = 'Q' ]] && exit
done
print "Database/Service is $srvname"

# get password for account sys for current ORACLE_SID
usrpwd=$(/home/oracle/scripts/getpwd.sh $ORACLE_SID SYS)

cnxsys="SYS/${usrpwd}@$srvname as sysdba"

sqlplus -s $cnxsys  <<!
set echo on
set lines 200
SELECT name, open_mode, database_role
FROM V\$DATABASE
/
select instance_name, host_name, startup_time, status
from v\$instance
/
!

