#!/bin/ksh

cat <<!
This is $0
Shows Data Guard configuration
!

typeset -u srvname
while [[ -z "$srvname" ]]
do
  read srvname?"Enter service name (q to quit) :"
  [[ $srvname = 'Q' ]] && exit
done
print "Service is $srvname"

# get password for account SYS for service name
usrpwd=$(/home/oracle/scripts/getpwd.sh $srvname SYS)
cnxsys="SYS/${usrpwd}@$srvname"

dgmgrl <<!
connect $cnxsys
show configuration
!
