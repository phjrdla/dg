alter system set standby_file_management=auto scope=both
/
