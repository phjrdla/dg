#!/bin/ksh

DATE=$(date '+%Y-%m-%d_%H:%M:%S')
RMAN_LOG="/u04/rman/BACKUP_FULL_${DATE}.lst"

[[ $ORACLE_SID = "" ]] && { print "ORACLE_SID is not defined"; exit; }

# get password for account system for current ORACLE_SID
usrpwd=$(/home/oracle/scripts/getpwd.sh $ORACLE_SID SYSTEM)
cnx="SYSTEM/${usrpwd}"

print $cnx


database_role=$(sqlplus -S $cnx <<!
set pagesize 0
set heading off
set feedback off
select database_role
from v\$database
/
!
)

print "Database_role is $database_role"

[[ $database_role = 'PRIMARY' ]] && { rman target $cnx @$DG_SCRIPTS/BACKUP_FULL.rman LOG $RMAN_LOG; ls -l $RMAN_LOG; }

